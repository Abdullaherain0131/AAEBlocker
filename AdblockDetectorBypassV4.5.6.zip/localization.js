class LocalizationHelper {
    static getMessage(key, substitutions = []) {
        return chrome.i18n.getMessage(key, substitutions);
    }

    static isRTL() {
        const locale = chrome.i18n.getUILanguage?.() || navigator.language;
        return locale.startsWith('ar');
    }

    static localizePage() {
        // Set RTL if needed
        if (this.isRTL()) {
            document.documentElement.dir = 'rtl';
            document.documentElement.classList.add('rtl');
        } else {
            document.documentElement.dir = 'ltr';
            document.documentElement.classList.remove('rtl');
        }

        // Localize elements with data-i18n attribute
        document.querySelectorAll('[data-i18n]').forEach(el => {
            const key = el.getAttribute('data-i18n');
            const substitutions = el.getAttribute('data-i18n-substitutions');
            let msg = this.getMessage(key);
            
            if (msg) {
                if (substitutions) {
                    const subArray = JSON.parse(substitutions);
                    msg = this.getMessage(key, subArray);
                }
                
                if (el.hasAttribute('data-i18n-html')) {
                    el.innerHTML = msg;
                } else {
                    el.textContent = msg;
                }
            }
        });

        // Localize placeholder attributes
        document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
            const key = el.getAttribute('data-i18n-placeholder');
            const msg = this.getMessage(key);
            if (msg) el.placeholder = msg;
        });

        // Localize title attributes
        document.querySelectorAll('[data-i18n-title]').forEach(el => {
            const key = el.getAttribute('data-i18n-title');
            const msg = this.getMessage(key);
            if (msg) el.title = msg;
        });

        // Localize value attributes (for inputs)
        document.querySelectorAll('[data-i18n-value]').forEach(el => {
            const key = el.getAttribute('data-i18n-value');
            const msg = this.getMessage(key);
            if (msg) el.value = msg;
        });
    }


    static formatMessage(key, ...args) {
        let template = this.getMessage(key);
        if (!template || args.length === 0) {
            return template || key;
        }
        
        let result = template;
        
        // Replace all {} placeholders with arguments in order
        for (let i = 0; i < args.length; i++) {
            // Replace {0}, {1}, {2}, etc.
            result = result.replace(new RegExp(`\\{${i}\\}`, 'g'), args[i]);
            
            // Replace common named placeholders with first argument
            if (i === 0) {
                const firstArgPlaceholders = ['{site}', '{count}', '{elements}', '{date}', '{selector}', '{version}'];
                firstArgPlaceholders.forEach(placeholder => {
                    if (result.includes(placeholder)) {
                        result = result.replace(new RegExp(placeholder, 'g'), args[0]);
                    }
                });
            }
            
            // Replace {sites} with second argument
            if (i === 1 && result.includes('{sites}')) {
                result = result.replace(/{sites}/g, args[1]);
            }
        }
        
        return result;
    }




    static replacePlaceholders(text, replacements) {
        return text.replace(/{(\w+)}/g, (match, key) => {
            return replacements[key] !== undefined ? replacements[key] : match;
        });
    }
}

// Make it available globally
window.LocalizationHelper = LocalizationHelper;

// Auto-localize on DOMContentLoaded if on a page
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        LocalizationHelper.localizePage();
    });
} else {
    LocalizationHelper.localizePage();
}